import Image from 'next/image';
import Link from 'next/link';
import { Price } from './price';
import type { ProductCardData } from '@/lib/types';

export function ProductCard({ product }: { product: ProductCardData }) {
  return (
    <Link
      href={`/product/${product.id}`}
      className="group flex flex-col overflow-hidden rounded-xl border border-neutral-200 bg-white transition hover:shadow-md"
    >
      <div className="relative aspect-square w-full bg-neutral-100">
        {product.photo ? (
          <Image
            src={product.photo}
            alt={product.title}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 50vw, 25vw"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-neutral-400">нет фото</div>
        )}
        {product.condition === 'used' && (
          <span className="absolute left-2 top-2 rounded bg-neutral-900/80 px-2 py-0.5 text-xs text-white">
            б/у
          </span>
        )}
      </div>
      <div className="flex flex-col gap-1 p-3">
        <div className="line-clamp-2 text-sm text-neutral-800 group-hover:text-brand">{product.title}</div>
        <Price value={product.price_kzt} className="font-semibold" />
        {product.shop && <div className="truncate text-xs text-neutral-500">{product.shop.name}</div>}
      </div>
    </Link>
  );
}
