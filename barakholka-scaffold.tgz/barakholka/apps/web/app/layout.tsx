import type { Metadata } from 'next';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: 'Барахолка — маркетплейс Алматы',
  description: 'Магазины и товары с Барахолки Алматы. Карта, поиск, связь с продавцом.',
};

const nav = [
  { href: '/', label: 'Главная' },
  { href: '/map', label: 'Карта' },
  { href: '/shops', label: 'Магазины' },
  { href: '/search', label: 'Поиск' },
] as const;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body className="flex min-h-full flex-col">
        <header className="sticky top-0 z-40 border-b border-neutral-200 bg-white/90 backdrop-blur">
          <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
            <Link href="/" className="text-lg font-semibold tracking-tight">
              Барахолка<span className="text-brand">.kz</span>
            </Link>
            <nav className="flex items-center gap-4 text-sm">
              {nav.map((item) => (
                <Link key={item.href} href={item.href} className="text-neutral-700 hover:text-brand">
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        </header>
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6">{children}</main>
        <footer className="border-t border-neutral-200 py-6 text-center text-xs text-neutral-500">
          © Барахолка.kz · Алматы · MVP
        </footer>
      </body>
    </html>
  );
}
