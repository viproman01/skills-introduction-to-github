import Link from 'next/link';
import { getSupabaseServer } from '@/lib/supabase/server';
import { ShopCard } from '@/components/shop-card';
import type { ShopSummary } from '@/lib/types';

const tiles = [
  { href: '/map', title: 'Карта', desc: 'Найди магазин по зоне и сектору.' },
  { href: '/shops', title: 'Магазины', desc: 'Проверенные продавцы Барахолки.' },
  { href: '/search', title: 'Поиск', desc: 'Ищи по названию и описанию.' },
] as const;

export default async function HomePage() {
  const popular = await fetchPopularShops();

  return (
    <div className="flex flex-col gap-10">
      <section className="rounded-2xl bg-gradient-to-br from-rose-50 to-white p-8 md:p-12">
        <h1 className="max-w-2xl text-3xl font-semibold tracking-tight md:text-4xl">
          Барахолка Алматы — в одном месте.
        </h1>
        <p className="mt-3 max-w-xl text-neutral-600">
          Магазины, товары и контакты продавцов. Найди нужное без прогулок по рядам.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link href="/map" className="rounded-lg bg-brand px-5 py-2.5 text-sm font-medium text-brand-fg hover:bg-rose-700">
            Открыть карту
          </Link>
          <Link href="/shops" className="rounded-lg border border-neutral-300 px-5 py-2.5 text-sm font-medium hover:border-neutral-500">
            Все магазины
          </Link>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {tiles.map((t) => (
          <Link
            key={t.href}
            href={t.href}
            className="rounded-xl border border-neutral-200 p-5 transition hover:border-rose-300 hover:shadow-sm"
          >
            <div className="text-lg font-medium">{t.title}</div>
            <div className="mt-1 text-sm text-neutral-600">{t.desc}</div>
          </Link>
        ))}
      </section>

      <section>
        <div className="mb-4 flex items-end justify-between">
          <h2 className="text-xl font-semibold">Популярные магазины</h2>
          <Link href="/shops" className="text-sm text-brand hover:underline">
            все →
          </Link>
        </div>
        {popular.length === 0 ? (
          <div className="rounded-xl border border-dashed border-neutral-300 p-8 text-center text-sm text-neutral-500">
            Пока нет данных. Запусти <code>pnpm seed</code>, чтобы заполнить базу.
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
            {popular.map((s) => (
              <ShopCard key={s.id} shop={s} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

async function fetchPopularShops(): Promise<ShopSummary[]> {
  try {
    const supabase = await getSupabaseServer();
    const { data } = await supabase
      .from('shop')
      .select(
        'id, name, row_number, place_number, photos, is_verified, sector:sector(code, floor, zone:zone(name, slug))',
      )
      .eq('is_active', true)
      .order('is_verified', { ascending: false })
      .limit(6);

    return (data ?? []) as unknown as ShopSummary[];
  } catch {
    return [];
  }
}
